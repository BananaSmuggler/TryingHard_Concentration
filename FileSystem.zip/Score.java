package com.example.concentration_tryinghard;

import org.json.JSONException;
import org.json.JSONObject;

public class Score {
        private static final String JSON_SCORE = "Score";
        private static final String JSON_NUMBER_OF_TILES = "Number Of Tiles";

        private int score;
        private int numberOfTiles;

        public Score(int score, int numberOfTiles){
            this.score = score;
            this.numberOfTiles = numberOfTiles;
        }

        public Score(JSONObject json) throws JSONException {
            this.score = json.getInt(JSON_SCORE);
            this.numberOfTiles = json.getInt(JSON_NUMBER_OF_TILES);;
        }

        public void setScore(int score){
            this.score = score;
        }

        public int getScore(){
            return score;
        }

        public void setNumberOfTiles(int number){
            numberOfTiles = number;
        }

        public int getNumberOfTiles(){
            return numberOfTiles;
        }

        public JSONObject toJSON() throws JSONException {
            JSONObject json = new JSONObject();
            json.put(JSON_SCORE, score);
            json.put(JSON_NUMBER_OF_TILES, numberOfTiles);

            return json;
        }

}
