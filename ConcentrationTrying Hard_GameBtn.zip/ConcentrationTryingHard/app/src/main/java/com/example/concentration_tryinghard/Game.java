package com.example.concentration_tryinghard;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Game extends AppCompatActivity {
    private Button button1, button2, button3, button4, button5, button6, button7,
            button8, button9, button10, button11, button12, button13, button14,
            button15, button16, button17, button18, button19, button20;
    private TextView textView1, textView2, textView3, textView4, textView5, textView6, textView7,
            textView8, textView9, textView10, textView11, textView12, textView13, textView14,
            textView15, textView16, textView17, textView18, textView19, textView20;
    private TextView scoreDisplay;
    private DisplayComponent dc1, dc2, dc3, dc4, dc5, dc6, dc7, dc8, dc9, dc10, dc11, dc12, dc13, dc14, dc15, dc16, dc17, dc18, dc19, dc20;
    private TilesStack checkStack = new TilesStack();
    private TilesStack wrongStack = new TilesStack();
    private int counter = 0;
    private int score = 0;
    private String[] answerKey = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J"}; //sample answer key
    private Button tryAgainBtn, newGameBtn, endGameBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // Initialize components
        initialButton();
        initialTextView();
        initialDisplayComponent();

        // Sets button listeners
        TryAgain();
        NewGame();
        EndGame();

        //Combination of the buttons
        DisplayComponent[] combinationForTwoWords = {dc1, dc2, dc5, dc6};
        DisplayComponent[] combinationForThreeWords = {dc1, dc2, dc3, dc5, dc6, dc7};
        DisplayComponent[] combinationForFourWords = {dc1, dc2, dc3, dc4, dc5, dc6, dc7, dc8};
        DisplayComponent[] combinationForFiveWords = {dc1, dc2, dc3, dc4, dc5, dc6, dc7, dc8, dc11, dc10};
        DisplayComponent[] combinationForSixWords = {dc1, dc2, dc3, dc4, dc5, dc6, dc7, dc8, dc9, dc10, dc11, dc12};
        DisplayComponent[] combinationForSevenWords = {dc1, dc2, dc3, dc4, dc5, dc6, dc7, dc8, dc9, dc10, dc11, dc12, dc14, dc15};
        DisplayComponent[] combinationForEightWords = {dc1, dc2, dc3, dc4, dc5, dc6, dc7, dc8, dc9, dc10, dc11, dc12, dc13, dc14, dc15, dc16};
        DisplayComponent[] combinationForNineWords = {dc1, dc2, dc3, dc4, dc5, dc6, dc7, dc8, dc9, dc10, dc11, dc12, dc13, dc14, dc15, dc16, dc18, dc19};
        DisplayComponent[] combinationForTenWords = {dc1, dc2, dc3, dc4, dc5, dc6, dc7, dc8, dc9, dc10, dc11, dc12, dc13, dc14, dc15, dc16, dc17, dc18, dc19, dc20};

        int numberOfTiles;
        Bundle extras = getIntent().getExtras();
        numberOfTiles = extras.getInt("NumberOfTiles");//Receive number of tiles from the dialog

        //Decide how many tiles gonna display at the screen
        switch(numberOfTiles){
            case 2:
                randomKey(combinationForTwoWords);
                display(combinationForTwoWords);
                break;
            case 3:
                randomKey(combinationForThreeWords);
                display(combinationForThreeWords);
                break;
            case 4:
                randomKey(combinationForFourWords);
                display(combinationForFourWords);
                break;
            case 5:
                randomKey(combinationForFiveWords);
                display(combinationForFiveWords);
                break;
            case 6:
                randomKey(combinationForSixWords);
                display(combinationForSixWords);
                break;
            case 7:
                randomKey(combinationForSevenWords);
                display(combinationForSevenWords);
                break;
            case 8:
                randomKey(combinationForEightWords);
                display(combinationForEightWords);
                break;
            case 9:
                randomKey(combinationForNineWords);
                display(combinationForNineWords);
                break;
            case 10:
                randomKey(combinationForTenWords);
                display(combinationForTenWords);
                break;
            default:

        }


    }

    /**
     * Randomize the word beneath the button
     * @param dc An array of components
     */
    private void randomKey(DisplayComponent[] dc){
        List<DisplayComponent> list = new ArrayList<DisplayComponent>();
        List<String> list1 = new ArrayList<String>();
        int i = 0;
        for(int k = 0; k < dc.length; k++){
            list.add(dc[k]);
            if(k < 10){
                list1.add(answerKey[k]);
            }
        }

        Collections.shuffle(list);
        Collections.shuffle(list1);

        for(int j = 0; j < dc.length; j = j + 2){
            list.get(j).getTextView().setText(list1.get(i));
            list.get(j + 1).getTextView().setText(list1.get(i));
            i++;
        }
    }

    /**
     * Display components at the screen, and setOnClickListener for each button that displayed at the screen
     * @param dc An array of components
     */
    private void display(DisplayComponent[] dc){
        for(int i = 0; i < dc.length; i++){
            final int j = i;
            Button temp = dc[i].getButton();

            temp.setVisibility(View.VISIBLE);
            temp.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    counter++;
                    checkAnswer(dc[j]);
                }
            });
        }
    }

    /**
     * When user click on a button, it will push into a stack
     * If counter go to two, then check whether the answer that the user clicked and the previous answer are match
     * If not match, then pop the previous one from the stack, and push in wrong stack with the one that user clicked
     * @param dc A pair of component that contain with button and textView
     */
    private void checkAnswer(DisplayComponent dc){
        DisplayComponent temp = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(Game.this);

        if(counter <= 2){
            dc.getTextView().setVisibility(View.VISIBLE);
            dc.getButton().setVisibility(View.GONE);
        }
        else{
            builder.setTitle("Alert Massage").setMessage("TRY AGAIN");
            builder.show();
        }

        if(counter == 2){
            temp = (DisplayComponent) checkStack.peek();
            String text1 = temp.getTextView().getText().toString();
            String text2 = dc.getTextView().getText().toString();

            if(text2.compareTo(text1) == 0){
                checkStack.push(dc);
                score = score + 2;
                scoreDisplay.setText(Integer.toString(score));
                counter = 0;
            }
            else{
                wrongStack.push(checkStack.pop());
                wrongStack.push(dc);

                if(score > 0){
                    score--;
                    scoreDisplay.setText(Integer.toString(score));
                }
            }
        }
        else {
            checkStack.push(dc);
        }

    }

    /**
     * When the user clicks the Try Again Button
     * Resets the last two cards they picked if they are incorrect choices
     */
    public void TryAgain() {
        tryAgainBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(wrongStack.isEmpty())) {
                    DisplayComponent d1 = (DisplayComponent)wrongStack.pop();
                    DisplayComponent d2 = (DisplayComponent)wrongStack.pop();
                    d1.getTextView().setVisibility(View.GONE);
                    d1.getButton().setVisibility(View.VISIBLE);
                    d2.getTextView().setVisibility(View.GONE);
                    d2.getButton().setVisibility(View.VISIBLE);
                    counter = 0;
                }
            }
        });
    }

    /**
     * When the user clicks the New Game Button
     * Allows user to re-pick how many cards they want on the board
     */
    public void NewGame() {
        newGameBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score = 0;
                Dialog newGame = new Dialog();
                newGame.show(getSupportFragmentManager(), "open dialog");
            }
        });
    }

    /**
     * When the user clicks the End Game button
     * Resets the board and returns to MainActivity
     */
    public void EndGame() {
        endGameBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score = 0;
                Intent i = new Intent ( Game.this, MainActivity.class);
                startActivity(i);
            }
        });
    }

    /**
     * Initial Button and assign ID for each one
     */
    private void initialButton(){
        button1 = (Button)findViewById(R.id.B_1);
        button2 = (Button)findViewById(R.id.B_2);
        button3 = (Button)findViewById(R.id.B_3);
        button4 = (Button)findViewById(R.id.B_4);
        button5 = (Button)findViewById(R.id.B_5);
        button6 = (Button)findViewById(R.id.B_6);
        button7 = (Button)findViewById(R.id.B_7);
        button8 = (Button)findViewById(R.id.B_8);
        button9 = (Button)findViewById(R.id.B_9);
        button10 = (Button)findViewById(R.id.B_10);
        button11 = (Button)findViewById(R.id.B_11);
        button12 = (Button)findViewById(R.id.B_12);
        button13 = (Button)findViewById(R.id.B_13);
        button14 = (Button)findViewById(R.id.B_14);
        button15 = (Button)findViewById(R.id.B_15);
        button16 = (Button)findViewById(R.id.B_16);
        button17 = (Button)findViewById(R.id.B_17);
        button18 = (Button)findViewById(R.id.B_18);
        button19 = (Button)findViewById(R.id.B_19);
        button20 = (Button)findViewById(R.id.B_20);

        tryAgainBtn = (Button)findViewById(R.id.tryAgain_button);
        newGameBtn = (Button)findViewById(R.id.newGame_button);
        endGameBtn = (Button)findViewById(R.id.endGame_button);
    }

    /**
     * Initial TextView and assign ID for each one
     */
    private void initialTextView(){
        textView1 = (TextView)findViewById(R.id.A_1);
        textView2 = (TextView)findViewById(R.id.A_2);
        textView3 = (TextView)findViewById(R.id.A_3);
        textView4 = (TextView)findViewById(R.id.A_4);
        textView5 = (TextView)findViewById(R.id.A_5);
        textView6 = (TextView)findViewById(R.id.A_6);
        textView7 = (TextView)findViewById(R.id.A_7);
        textView8 = (TextView)findViewById(R.id.A_8);
        textView9 = (TextView)findViewById(R.id.A_9);
        textView10 = (TextView)findViewById(R.id.A_10);
        textView11 = (TextView)findViewById(R.id.A_11);
        textView12 = (TextView)findViewById(R.id.A_12);
        textView13 = (TextView)findViewById(R.id.A_13);
        textView14 = (TextView)findViewById(R.id.A_14);
        textView15 = (TextView)findViewById(R.id.A_15);
        textView16 = (TextView)findViewById(R.id.A_16);
        textView17 = (TextView)findViewById(R.id.A_17);
        textView18 = (TextView)findViewById(R.id.A_18);
        textView19 = (TextView)findViewById(R.id.A_19);
        textView20 = (TextView)findViewById(R.id.A_20);

        scoreDisplay = (TextView)findViewById(R.id.score_display);
    }

    /**
     * Assign button and textView as a pair, use as a united component
     */
    private void initialDisplayComponent(){
        dc1 = new DisplayComponent(button1, textView1);
        dc2 = new DisplayComponent(button2, textView2);
        dc3 = new DisplayComponent(button3, textView3);
        dc4 = new DisplayComponent(button4, textView4);
        dc5 = new DisplayComponent(button5, textView5);
        dc6 = new DisplayComponent(button6, textView6);
        dc7 = new DisplayComponent(button7, textView7);
        dc8 = new DisplayComponent(button8, textView8);
        dc9 = new DisplayComponent(button9, textView9);
        dc10 = new DisplayComponent(button10, textView10);
        dc11 = new DisplayComponent(button11, textView11);
        dc12 = new DisplayComponent(button12, textView12);
        dc13 = new DisplayComponent(button13, textView13);
        dc14 = new DisplayComponent(button14, textView14);
        dc15 = new DisplayComponent(button15, textView15);
        dc16 = new DisplayComponent(button16, textView16);
        dc17 = new DisplayComponent(button17, textView17);
        dc18 = new DisplayComponent(button18, textView18);
        dc19 = new DisplayComponent(button19, textView19);
        dc20 = new DisplayComponent(button20, textView20);
    }
}