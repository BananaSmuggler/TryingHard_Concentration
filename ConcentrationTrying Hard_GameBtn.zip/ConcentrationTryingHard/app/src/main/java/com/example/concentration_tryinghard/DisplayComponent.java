package com.example.concentration_tryinghard;

import android.widget.Button;
import android.widget.TextView;

//use for storing component that about to display
public class DisplayComponent {
        private Button button;
        private TextView textView;

        public DisplayComponent(Button b, TextView t){
            this.button = b;
            this.textView = t;
        }

        public Button getButton(){//getter for button
            return button;
        }

        public TextView getTextView(){
            return textView;
        }
}
